%% Prompt:
% Please write the code to generate data for 'case57' with the 'Random' base type, 300 training samples, and enable parallel computation.

%% Code Writen by LLM:
data = daline.data('case.name', 'case57', 'data.baseType', 'Random', 'num.trainSample', 300, 'data.parallel', 1);

%% MATLAB:
% The above code ran successfully