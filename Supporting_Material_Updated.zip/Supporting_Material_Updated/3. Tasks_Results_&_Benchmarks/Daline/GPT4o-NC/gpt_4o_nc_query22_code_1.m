%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Generate data
data = daline.data('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);

% Fit the model using LS_HBW
model = daline.fit(data, 'method.name', 'LS_HBW');

% Visualize the linearization results
daline.plot(model, 'PLOT.style', 'dark', 'PLOT.theme', 'academic', 'PLOT.switch', 0);

%% MATLAB:
% The above code ran successfully