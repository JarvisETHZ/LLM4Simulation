%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Generate data for 'case14'
data = daline.generateData('case14', 'samples.train', 300, 'samples.test', 200);

% Set options for LS_HBW method
opt = daline.setopt('method.name', 'LS_HBW', ...
                    'variable.predictor', {'P', 'Q'}, ...
                    'variable.response', {'PF', 'Vm'}, ...
                    'HBW.TuningConst', [0.8:0.1:1.5], ...
                    'HBW.PCA', 0);

% Fit the model using LS_HBW method
model = daline.fit(data, opt);

% Visualize the linearization results with specified styles and themes
daline.visualize(model, 'style', 'dark', 'theme', 'academic', 'plotting', 0);