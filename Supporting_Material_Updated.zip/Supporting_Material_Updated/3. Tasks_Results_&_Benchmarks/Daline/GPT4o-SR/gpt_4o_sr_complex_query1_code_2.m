%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare and rank the accuracy of the ordinary least squares, and the ordinary ridge regression for 'case14'. Set the regularization factor as 1e-10 for the ordinary ridge regression. Set the plotting responses to {'P', 'Vm2'} for all methods. Finally, use the dark style for plotting the ranking, and set the type of plotting as 'probability'. Disable the plotting. 

%% Code Writen by LLM:
% Step 1: Generate data for 'case14' with 400 training samples and 200 testing samples
data = daline.data('case14', 'num.trainSample', 400, 'num.testSample', 200);

% Step 2: Fit the ordinary least squares (OLS) model
model_OLS = daline.fit(data, 'method.name', 'LS', 'variable.response', {'P', 'Vm2'});

% Step 3: Fit the ordinary ridge regression (RR) model with regularization factor 1e-10
model_RR = daline.fit(data, 'method.name', 'RR', 'variable.response', {'P', 'Vm2'}, 'RR.lambdaInterval', 1e-10);

% Step 4: Compare and rank the accuracy of the models
comparison = daline.compare(data, 'model.list', {model_OLS, model_RR}, 'plot.response', {'P', 'Vm2'}, 'plot.style', 'dark', 'plot.type', 'probability', 'plot.flag', false);

% Display the comparison results
disp(comparison);