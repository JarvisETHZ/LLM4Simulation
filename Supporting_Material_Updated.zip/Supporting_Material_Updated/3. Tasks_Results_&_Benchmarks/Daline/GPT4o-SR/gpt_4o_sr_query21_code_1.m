%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Visualize the linearization results for Ridge Regression with the 'academic' theme and disable the plotting.

%% Code Writen by LLM:
% Generate data for 'case39'
data = daline.data('case39', 'data.baseType', 'TimeSeriesRand', 'data.trainSize', 500, 'data.testSize', 250);

% Set options for Ridge Regression
opt = daline.setopt('method.name', 'RR', 'plot.theme', 'academic', 'plot.flag', 0);

% Train the model using Ridge Regression
model = daline.fit(data, opt);

% Visualize the linearization results
daline.plot(model, 'plot.theme', 'academic', 'plot.flag', 0);