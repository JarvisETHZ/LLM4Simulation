%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD. Set the data base type to 'TimeSeriesRand' and the number of training samples to 300. Disable the plotting.

%% Code Writen by LLM:
% Manage a complete cycle for 'case118' using LS_COD
 daline = daline.all('case.name', 'case118', 'method.name', 'LS_COD', 'data.baseType', 'TimeSeriesRand', 'num.trainSample', 300, 'PLOT.switch', 0);