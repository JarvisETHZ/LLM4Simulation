%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. 
% Filter out outliers from the training and testing datasets using the 'grubbs' method. 
% Set the tolerance level for outlier detection as 0.7.

%% Code Written by LLM:
% https://chatgpt.com/share/486491b9-5e8c-4464-8ef4-de6485d7de72
% Set options for data generation
opt_generate = daline.setopt('case.name', 'case14', ...
                             'num.trainSample', 400, ...
                             'num.testSample', 200, ...
                             'data.program', 'acpf', ...
                             'data.baseType', 'TimeSeriesRand');

% Generate data
data = daline.generate(opt_generate);

% Set options for filtering out outliers
opt_deoutlier = daline.setopt('filOut.switchTrain', 1, ...
                              'filOut.switchTest', 1, ...
                              'filOut.method', 'grubbs', ...
                              'filOut.tol', 0.7);

% Filter out outliers
data = daline.deoutlier(data, opt_deoutlier);

% Display a summary of the generated data
disp('Data generation and outlier filtering completed.');
disp('Training data size:');
disp(size(data.train.P));
disp('Testing data size:');
disp(size(data.test.P));

%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', ...
% 'data.baseType', 'TimeSeriesRand'