%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD.
% Set the data base type to 'TimeSeriesRand' and the number of training samples to 300.
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/a10cdf58-143b-49e2-80b0-d1aa0db586fa
% Load the necessary data and set the options for the LS_COD method.
data = daline.data('case.name', 'case118', 'data.base', 'TimeSeriesRand', 'data.sample', 300);

% Set the method to LS_COD and disable plotting
opt = daline.setopt('method.name', 'LS_COD', 'PLOT.enable', 0);

% Fit the model using the specified method and options
model = daline.fit(data, opt);

% Display the model parameters and any relevant output
disp(model);
