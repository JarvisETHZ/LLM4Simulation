%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples.
% Train a model using PLS_CLS.

%% Code Written by LLM:
% https://chatgpt.com/share/022a6525-5daa-44a6-a377-33b1182d62ac
% Set up the options for data generation
opt = daline.setopt('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 250, ...
                    'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand');

% Generate the data
data = daline.generate(opt);

% Train the model using PLS_CLS method
model = daline.fit(data, 'method.name', 'PLS_CLS');

% Display the model details
disp(model);


%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand'