%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Normalize both training and testing datasets.

%% Code Writen by LLM:
% https://chatgpt.com/share/3dcfb59f-122c-4fba-9f04-f4c1872a0a9f
% Set up the options for data generation
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200, 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand');

% Generate the data
data = daline.generate(opt);

% Normalize the data
data = daline.normalize(data);

% Display the data structure to verify
disp(data);

%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand'