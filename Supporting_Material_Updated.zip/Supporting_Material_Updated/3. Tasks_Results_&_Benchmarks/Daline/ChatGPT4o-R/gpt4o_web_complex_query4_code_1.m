%% Prompt:
% Generate data for 'case118' with 600 training samples and 300 testing samples.
% Compare and rank the accuracy of LS_COD and RR_VCS for 'case118'.
% Set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'} for both methods.
% Set the lambda interval for Ordinary Ridge Regression with the Voltage-angle Coupling to 1e-7.
% Set the plotting theme as 'academic', but disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/df52c65e-e6c7-48c1-b8a4-29089bf95c57
% Generate the data
opt = daline.setopt('case.name', 'case118', ...
                    'num.trainSample', 600, ...
                    'num.testSample', 300, ...
                    'data.program', 'acpf', ...
                    'data.baseType', 'TimeSeriesRand', ...
                    'data.fixRand', 1, ...
                    'data.curvePlot', 0);
data = daline.generate(opt);

% Set predictors and responses
opt = daline.setopt(opt, 'variable.predictor', {'P', 'Vm2'}, ...
                          'variable.response', {'PF', 'QF'});

% LS_COD method
opt_ls = daline.setopt(opt, 'method.name', 'LS_COD', ...
                            'plot.theme', 'academic', ...
                            'plot.display', 0);
model_ls = daline.fit(data, opt_ls);

% RR_VCS method
opt_rr = daline.setopt(opt, 'method.name', 'RR_VCS', ...
                            'RR.lambdaInterval', 1e-7, ...
                            'plot.theme', 'academic', ...
                            'plot.display', 0);
model_rr = daline.fit(data, opt_rr);

% Compare accuracy
accuracy_ls = daline.accuracy(data, model_ls);
accuracy_rr = daline.accuracy(data, model_rr);

% Rank the methods based on accuracy
if accuracy_ls > accuracy_rr
    fprintf('LS_COD is more accurate than RR_VCS.\n');
else
    fprintf('RR_VCS is more accurate than LS_COD.\n');
end
