
%% Prompt:
% Please write the code to manage a complete cycle for 'case39' using the method SVD. 
% Set the data base type to 'TimeSeries' and the number of training samples to 300. 
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/01efde14-d991-4ce6-afbd-78ea28fc264f
% Define the parameters for data generation and model fitting
opt = daline.setopt('case.name', 'case39', ...                 % Set the case name to 'case39'
                    'num.trainSample', 300, ...               % Set the number of training samples to 300
                    'data.baseType', 'TimeSeries', ...        % Set the data base type to 'TimeSeries'
                    'data.curvePlot', 0, ...                  % Disable the plotting
                    'method.name', 'SVD', ...                 % Set the method to 'SVD'
                    'variable.predictor', {'P', 'Q'}, ...     % Set predictors to active and reactive power
                    'variable.response', {'PF', 'QF'});       % Set responses to active and reactive branch flows

% Generate the data
data = daline.generate(opt);

% Fit the model using the specified method and options
model = daline.fit(data, opt);

% Display the model summary
disp(model);

%% MATLAB:
% The above code ran successfully

%% Hidden Mistake:
% daline.fit is not the full cycle function
