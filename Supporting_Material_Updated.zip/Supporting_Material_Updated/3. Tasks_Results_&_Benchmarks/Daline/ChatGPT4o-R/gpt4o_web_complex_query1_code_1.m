%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples.
% Compare and rank the accuracy of the ordinary least squares, and the ordinary 
% ridge regression for 'case14'. Set the regularization factor as 1e-10 for the 
% ordinary ridge regression. Set the plotting responses to {'P', 'Vm2'} for all methods. 
% Finally, use the dark style for plotting the ranking, and set the type of plotting 
% as 'probability'. Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/a95b84fb-02bf-44ea-afc5-f4fb98d3ee1b
% Set up options for data generation
opt_gen = daline.setopt('case.name', 'case14', ...
                        'num.trainSample', 400, ...
                        'num.testSample', 200, ...
                        'data.program', 'acpf', ...
                        'data.baseType', 'TimeSeriesRand', ...
                        'data.curvePlot', 0);

% Generate data
data = daline.generate(opt_gen);

% Set up options for the methods to be compared and ranked
opt_rank = daline.setopt('method.name', {'LS', 'RR'}, ...
                         'variable.response', {'P', 'Vm2'}, ...
                         'RR.lambdaInterval', 1e-10, ...
                         'PLOT.style', 'dark', ...
                         'PLOT.type', 'probability', ...
                         'PLOT.show', 0);

% Compare and rank the methods
results = daline.rank(data, {'LS', 'RR'}, opt_rank);

% Display the ranking results (disabled plotting as requested)
disp(results);
