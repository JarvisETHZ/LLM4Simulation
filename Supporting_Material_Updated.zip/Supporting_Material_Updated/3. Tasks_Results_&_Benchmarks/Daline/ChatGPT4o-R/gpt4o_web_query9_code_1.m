%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples.
% Add outliers to the training dataset with a percentage of 5%.

%% Code Written by LLM:
% https://chatgpt.com/share/3165064d-f674-44ef-8864-a24da9ebb83f
% Setting up the options for data generation
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, ...
                    'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', ...
                    'data.fixRand', 1, 'data.fixSeed', 88);

% Generating the data
data = daline.generate(opt);

% Adding outliers to the training dataset
opt_outlier = daline.setopt('outlier.switchTrain', 1, 'outlier.percentage', 5);
data = daline.outlier(data, opt_outlier);

% Displaying the resulting data structure
disp(data);

%% MATLAB:
% The above code ran successfully

%% Unnecessary settings
% 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 
% 'data.fixRand', 1, 'data.fixSeed', 88