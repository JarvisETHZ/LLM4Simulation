%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. 
% Compare and rank the computing efficiency of the following methods: the ordinary least squares, 
% the locally weighted ridge regression, DC, TAY, and DLPF_C. Set the number of folds for the method 
% Locally Weighted Ridge Regression as 3, and its random seed number as 18. 
% Set point0 of the method TAY as 'end'. Use 2 repetitions for plotting. 
% Use the light style for plotting, but disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/83db403d-5fdf-46c8-97ce-6f0094c94242
% Step 1: Generate data
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200, ...
                    'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand');
data = daline.generate(opt);

% Step 2: Set options for methods and comparison
opt_ols = daline.setopt('method.name', 'OLS');
opt_lwrr = daline.setopt('method.name', 'RR_KPC', 'RR.cvNumFold', 3, 'RR.fixSeed', 18);
opt_dc = daline.setopt('method.name', 'DC');
opt_tay = daline.setopt('method.name', 'TAY', 'TAY.point0', 'end');
opt_dlpf_c = daline.setopt('method.name', 'DLPF_C');

% Step 3: Time the methods
method_list = {'OLS', 'RR_KPC', 'DC', 'TAY', 'DLPF_C'};
opt_list = {opt_ols, opt_lwrr, opt_dc, opt_tay, opt_dlpf_c};

timeList = daline.time(data, method_list, ...
                       'PLOT.repeat', 2, 'PLOT.style', 'light', 'PLOT.switch', 0);

% Step 4: Rank and compare computing efficiency
% Display the results
disp('Computing Efficiency Results:');
disp(timeList);
