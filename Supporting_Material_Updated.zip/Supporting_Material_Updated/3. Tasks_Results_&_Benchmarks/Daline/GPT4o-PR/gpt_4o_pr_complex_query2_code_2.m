%% Prompt:
% Generate data for 'case9' with 200 training samples and 150 testing samples. Compare and rank the accuracy of the following methods: PLS_RECW, TAY, the decoupled linearized power flow approach, RR_KPC, the ordinary least squares method, and the QR decomposition. Set the new data percentage for the method PLS_RECW to 20%, and its forgetting factor value as 0.7. Set point0 of the method TAY as 200. For the method RR_KPC, set the discrete range of tuning eta as logspace(2,5,5), and fix the random seed as 66 for RR_KPC. Set the response to {'Vm'} for all methods. Finally, use the light style for plotting the ranking, and set the type of plotting as 'probability'. Disable the plotting. 

%% Code Writen by LLM:
% Step 1: Generate data for 'case9' with 200 training samples and 150 testing samples
opt = daline.setopt('case.name', 'case9', 'num.trainSample', 200, 'num.testSample', 150);
data = daline.data(opt);

% Step 2: Define options for each method
opt_PLS_RECW = daline.setopt('method.name', 'PLS_RECW', 'variable.response', {'Vm'}, 'PLS.recursivePercentage', 20, 'PLS.omega', 0.7);
opt_TAY = daline.setopt('method.name', 'TAY', 'variable.response', {'Vm'}, 'TAY.point0', 200);
opt_DLPF = daline.setopt('method.name', 'DLPF', 'variable.response', {'Vm'});
opt_RR_KPC = daline.setopt('method.name', 'RR_KPC', 'variable.response', {'Vm'}, 'RR.etaInterval', logspace(2, 5, 5), 'RR.fixSeed', 66);
opt_LS = daline.setopt('method.name', 'LS', 'variable.response', {'Vm'});
opt_QR = daline.setopt('method.name', 'QR', 'variable.response', {'Vm'});

% Step 3: Fit models for each method
model_PLS_RECW = daline.fit(data, opt_PLS_RECW);
model_TAY = daline.fit(data, opt_TAY);
model_DLPF = daline.fit(data, opt_DLPF);
model_RR_KPC = daline.fit(data, opt_RR_KPC);
model_LS = daline.fit(data, opt_LS);
model_QR = daline.fit(data, opt_QR);

% Step 4: Compare and rank the accuracy of the methods
rank_opt = daline.setopt('PLOT.enable', 0, 'PLOT.style', 'light', 'PLOT.type', 'probability');
methods = {'PLS_RECW', 'TAY', 'DLPF', 'RR_KPC', 'LS', 'QR'};
ranking = daline.rank(data, methods, rank_opt);

% Display the ranking results
disp(ranking);