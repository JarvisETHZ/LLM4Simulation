%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Set options for data generation
opt_data = daline.setopt('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);

% Generate the data
data = daline.data(opt_data);

% Set options for fitting the model using LS_HBW
opt_fit = daline.setopt('method.name', 'LS_HBW', 'variable.predictor', {'P', 'Q'}, 'variable.response', {'PF', 'Vm'});

% Fit the model
model = daline.fit(data, opt_fit);

% Set options for plotting the results
opt_plot = daline.setopt('PLOT.response', {'Vm', 'PF'}, 'PLOT.theme', 'academic', 'PLOT.style', 'dark', 'PLOT.switch', 0);

% Plot the results
daline.plot(model, opt_plot);

%% MATLAB:
% The above code ran successfully

%% Unnecessary
% 'variable.predictor', {'P', 'Q'}, 'variable.response', {'PF', 'Vm'}, 'PLOT.response', {'Vm', 'PF'}