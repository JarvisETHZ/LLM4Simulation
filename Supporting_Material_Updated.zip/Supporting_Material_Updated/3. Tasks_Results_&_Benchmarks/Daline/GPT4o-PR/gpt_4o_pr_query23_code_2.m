%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Set options for data generation
opt_data = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);

% Generate data
data = daline.all(opt_data);

% Set options for PLS_CLS model fitting
opt_model = daline.setopt('method.name', 'PLS_CLS', 'variable.predictor', {'P', 'Q'}, 'variable.response', {'PF', 'Vm'}, 'PLS.fixKmeans', 0, 'PLS.clusNumInterval', 6:2:12, 'PLS.cvNumFold', 5);

% Fit the model
model = daline.fit(data, opt_model);

% Set options for plotting
opt_plot = daline.setopt('PLOT.response', {'Vm', 'PF'}, 'PLOT.theme', 'academic', 'PLOT.style', 'light', 'PLOT.switch', 0);

% Plot the results
daline.plot(model, opt_plot);