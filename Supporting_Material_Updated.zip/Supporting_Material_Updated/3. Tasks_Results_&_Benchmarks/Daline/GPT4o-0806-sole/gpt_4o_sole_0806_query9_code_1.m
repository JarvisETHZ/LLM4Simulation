%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Add outliers to the training dataset with a percentage of 5%. 

%% Code Writen by LLM:
% Load the case
mpc = loadcase('case14');

% Set parameters for data generation
params = struct();
params.nSamples = 400; % Number of training samples
params.nTestSamples = 200; % Number of testing samples
params.outlierFraction = 0.05; % 5% outliers in the training dataset

% Generate data
[dataTrain, dataTest] = generateData(mpc, params);

% Add outliers to the training data
dataTrainWithOutliers = addOutliers(dataTrain, params.outlierFraction);