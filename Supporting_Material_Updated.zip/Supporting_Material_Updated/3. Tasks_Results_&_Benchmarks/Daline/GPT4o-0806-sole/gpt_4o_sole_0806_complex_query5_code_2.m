%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Rank the accuracy of LS and QR Decomposition for 'case14'. Set the variable predictors to {'P', 'Vm2'} and variable responses to {'PF'} for both methods. Set the plotting response as {'PF'}. Use the name-value pairs to set the settings of both methods simultaneously. Finally, disable the plotting. 

%% Code Writen by LLM:
% Load the case14 data
mpc = loadcase('case14');

% Generate data for 'case14' with 300 training samples and 200 testing samples
data = generate_data('mpc', mpc, 'train', 300, 'test', 200);

% Set the variable predictors and responses
predictors = {'P', 'Vm2'};
responses = {'PF'};

% Set the plotting response
plotting_response = {'PF'};

% Rank the accuracy of LS and QR Decomposition
results = rank_accuracy(data, 'methods', {'LS', 'QR'}, ...
                        'predictors', predictors, ...
                        'responses', responses, ...
                        'plotting_response', plotting_response, ...
                        'LS.plotting', false, ...
                        'QR.plotting', false);