%% Prompt:
% Generate data for 'case39' with 500 training samples and 250 testing samples. Add outliers to the training data with a factor of 3 and an outlier percentage of 2.5%.

%% Code Writen by LLM:
% Generate data for 'case39' with 500 training samples and 250 testing samples
% Add outliers to the training data with a factor of 3 and an outlier percentage of 2.5%

% Define the parameters for data generation
data_params = struct();
data_params.caseName = 'case39';
data_params.nTrain = 500;
data_params.nTest = 250;
data_params.outlierFactor = 3;
data_params.outlierPerc = 2.5;

% Generate the data using the correct function
data = DataGen.generate(data_params);