%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Introduce outliers into the data with an outlier percentage of 5% and a factor of 2.

%% Code Writen by LLM:
% Define the parameters for data generation
case_name = 'case14';
n_train = 300;
n_test = 200;
outlier_perc = 5; % Percentage of outliers
outlier_factor = 2; % Factor by which outliers are scaled

% Generate the data using the correct function name
generateData(case_name, n_train, n_test, outlier_perc, outlier_factor);