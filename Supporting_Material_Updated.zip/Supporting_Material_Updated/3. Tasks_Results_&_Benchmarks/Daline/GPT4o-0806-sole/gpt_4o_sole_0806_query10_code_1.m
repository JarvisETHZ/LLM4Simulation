%% Prompt:
% Generate data for 'case57' with 600 training samples and 300 testing samples. Add noise to the training data with a SNR of 45dB. Then Filter out noise from the training dataset.

%% Code Writen by LLM:
% Load the case57 power system data
mpc = loadcase('case57');

% Set parameters for data generation
num_train_samples = 600;
num_test_samples = 300;
snr_value = 45; % Signal-to-Noise Ratio in dB

% Generate training data with noise
train_data = generate_data(mpc, 'samples', num_train_samples, 'noise', snr_value);

% Generate testing data without noise
test_data = generate_data(mpc, 'samples', num_test_samples);

% Filter out noise from the training dataset
filtered_train_data = filter_data(train_data);

% Display the size of the generated datasets
disp(['Training data size: ', num2str(size(filtered_train_data, 1))]);
disp(['Testing data size: ', num2str(size(test_data, 1))]);