%% Prompt:
% Please write the code to prepare data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation.

%% Code Writen by LLM:
% Generate data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation
DataGen('case118', 'BaseType', 'TimeSeriesRand', 'NumTrain', 500, 'Parallel', true);