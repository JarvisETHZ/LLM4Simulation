%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Visualize the linearization results of Partial Least Squares with Clustering with a light style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Generate data for 'case14' with 400 training samples and 200 testing samples
data = generateData('case14', 'n_train', 400, 'n_test', 200);

% Visualize the linearization results of Partial Least Squares with Clustering
visualize(data, 'method', 'PLS_clustering', 'style', 'light', 'theme', 'academic', 'plotting', false);