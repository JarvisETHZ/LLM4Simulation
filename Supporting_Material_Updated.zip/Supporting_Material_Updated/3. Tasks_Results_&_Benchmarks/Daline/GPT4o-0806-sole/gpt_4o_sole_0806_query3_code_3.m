%% Prompt:
% Please write the code to produce data for 'case39' with the 'TimeSeries' base type, 500 training samples, turn on the fixed-randomness mode, and use a random seed of 188. 

%% Code Writen by LLM:
% Set parameters for data generation
caseName = 'case39';
baseType = 'TimeSeries';
nSample = 500;
fixedRandomness = true;
randomSeed = 188;

% Generate data
dataGen(caseName, baseType, nSample, 'fixedRandomness', fixedRandomness, 'randomSeed', randomSeed);