%% Prompt:
% Generate data for 'case14' with 200 training samples and 150 testing samples. Train and test a model using RR_KPC, while set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'}.

%% Code Writen by LLM:
% Generate data for 'case14'
data = generate_data('case14', 'train', 200, 'test', 150);

% Train the model using RR_KPC
model = train(data, 'RR_KPC', 'predictors', {'P', 'Vm2'}, 'responses', {'PF', 'QF'});

% Test the model
results = test(model, data);