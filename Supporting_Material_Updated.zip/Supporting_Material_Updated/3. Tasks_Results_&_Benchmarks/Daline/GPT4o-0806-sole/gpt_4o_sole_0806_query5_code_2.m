%% Prompt:
% Please write the code to prepare data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation.

%% Code Writen by LLM:
% Generate training data for 'case118' with 500 samples, 'TimeSeriesRand' base type, and enable parallel computation
DataGen_Train('case118', 'BaseType', 'TimeSeriesRand', 'NumTrain', 500, 'Parallel', true);