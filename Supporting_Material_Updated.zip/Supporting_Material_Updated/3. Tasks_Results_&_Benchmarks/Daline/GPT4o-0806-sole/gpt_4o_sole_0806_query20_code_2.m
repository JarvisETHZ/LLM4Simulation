%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Load the case
mpc = loadcase('case14');

% Set parameters for data generation
params = struct();
params.n_train = 400; % Number of training samples
params.n_test = 200;  % Number of testing samples

% Generate data
data = generateData(mpc, params);

% Set parameters for Decoupled Linearized Power Flow with Data-driven Correction
params_dlpf = struct();
params_dlpf.method.name = 'DLFDC'; % Decoupled Linearized Power Flow with Data-driven Correction

% Set parameters for Power Transfer Distribution Factor
params_ptdf = struct();
params_ptdf.method.name = 'PTDF'; % Power Transfer Distribution Factor

% Evaluate accuracy for Decoupled Linearized Power Flow with Data-driven Correction
accuracy_dlpf = evaluateAccuracy(data, params_dlpf);

% Evaluate accuracy for Power Transfer Distribution Factor
accuracy_ptdf = evaluateAccuracy(data, params_ptdf);

% Display the results
fprintf('Accuracy of Decoupled Linearized Power Flow with Data-driven Correction: %.2f%%\n', accuracy_dlpf * 100);
fprintf('Accuracy of Power Transfer Distribution Factor: %.2f%%\n', accuracy_ptdf * 100);