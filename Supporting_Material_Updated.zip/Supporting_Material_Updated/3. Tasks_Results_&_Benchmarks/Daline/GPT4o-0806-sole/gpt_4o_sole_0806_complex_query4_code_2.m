%% Prompt:
% Generate data for 'case118' with 600 training samples and 300 testing samples. Compare and rank the accuracy of LS_COD and RR_VCS for 'case118'. Set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'} for both methods. Set the lambda interval for Ordinary Ridge Regression with the Voltage-angle Coupling to 1e-7. Finally, set the plotting theme as 'academic', but disable the plotting. 

%% Code Writen by LLM:
% Generate data for 'case118' with 600 training samples and 300 testing samples
data = generate_data('case118', 'train_size', 600, 'test_size', 300);

% Set predictors and responses
predictors = {'P', 'Vm2'};
responses = {'PF', 'QF'};

% Set lambda interval for Ordinary Ridge Regression with Voltage-angle Coupling
RR.lambdaInterval = 1e-7;

% Set plotting theme and disable plotting
plotting.theme = 'academic';
plotting.enabled = false;

% Compare and rank the accuracy of LS_COD and RR_VCS
results = compare_methods(data, ...
    'methods', {'LS_COD', 'RR_VCS'}, ...
    'predictors', predictors, ...
    'responses', responses, ...
    'RR.lambdaInterval', RR.lambdaInterval, ...
    'plotting.theme', plotting.theme, ...
    'plotting.enabled', plotting.enabled);

% Display the results
disp(results);