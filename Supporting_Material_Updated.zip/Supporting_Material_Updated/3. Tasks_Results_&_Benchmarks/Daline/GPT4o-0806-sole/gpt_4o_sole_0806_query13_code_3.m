%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set parameters for data generation
num_train_samples = 400;
num_test_samples = 200;

% Generate training data
train_data = generate_data('caseName', 'case14', 'n', num_train_samples);

% Generate testing data
test_data = generate_data('caseName', 'case14', 'n', num_test_samples);

% Set parameters for outlier filtering
outlier_method = 'grubbs';
tolerance_level = 0.7;

% Filter out outliers from training data
filtered_train_data = filter_outliers(train_data, 'method', outlier_method, 'tol', tolerance_level);

% Filter out outliers from testing data
filtered_test_data = filter_outliers(test_data, 'method', outlier_method, 'tol', tolerance_level);