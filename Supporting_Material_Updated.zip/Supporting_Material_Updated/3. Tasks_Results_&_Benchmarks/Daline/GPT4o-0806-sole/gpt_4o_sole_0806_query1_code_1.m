%% Prompt:
% Please write the code to generate training and testing data sets for 'case118' using the 'acpf' program and 'TimeSeriesRand' as the base type. Set the number of training samples to 300 and the number of testing samples to 200.

%% Code Writen by LLM:
% Define the base type and the power flow program
baseType = 'TimeSeriesRand';
program = 'acpf';

% Set the number of samples for training and testing
numTrain = 300;
numTest = 200;

% Generate training data
generateData('case118', ...
    'baseType', baseType, ...
    'program', program, ...
    'numTrain', numTrain);

% Generate testing data
generateData('case118', ...
    'baseType', baseType, ...
    'program', program, ...
    'numTest', numTest);