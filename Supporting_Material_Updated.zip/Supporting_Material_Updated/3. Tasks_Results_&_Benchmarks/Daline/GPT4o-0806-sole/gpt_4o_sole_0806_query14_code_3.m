%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Normalize both training and testing datasets. 

%% Code Writen by LLM:
% Load the case14 system
mpc = loadcase('case14');

% Set the number of samples
num_train_samples = 300;
num_test_samples = 200;

% Generate training data
train_data = DataGen_case(mpc, 'samples', num_train_samples);

% Normalize training data
[train_data_normalized, norm_params] = DataNorm_case(train_data);

% Generate testing data
test_data = DataGen_case(mpc, 'samples', num_test_samples);

% Normalize testing data using the same parameters as training data
test_data_normalized = DataNorm_case(test_data, 'params', norm_params);

% Save or use the normalized data as needed