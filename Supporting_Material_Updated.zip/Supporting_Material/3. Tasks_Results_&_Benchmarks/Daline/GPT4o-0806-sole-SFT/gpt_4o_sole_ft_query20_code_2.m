%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Generate data for 'case14' with 400 training samples and 200 testing samples
 data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);

 % Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction (DLPF.dc) and Power Transfer Distribution Factor (PTDF)
 models = daline.CMP(data, {'DLPF.dc', 'PTDF'});