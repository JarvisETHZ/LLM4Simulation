%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Generate data for 'case14' with 300 training samples and 200 testing samples
 data = daline.data('case.name', 'case14', 'num.trainSample', 300, 'num.testSample', 200);

 % Linearize using Least Squares with Huber Weighting Function
 model = daline.fit(data, 'method.name', 'LS_HUBER');

 % Visualize the linearization results with a dark style and an academic theme, but disable the plotting
 daline.plot(model, 'PLOT.style', 'dark', 'PLOT.theme', 'academic', 'PLOT.switch', 0);