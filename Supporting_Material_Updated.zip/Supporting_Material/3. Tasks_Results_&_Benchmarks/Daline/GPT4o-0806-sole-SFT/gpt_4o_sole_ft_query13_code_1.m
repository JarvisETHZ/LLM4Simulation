%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Filter out outliers from the training and testing datasets using the 'grubbs' method. Set the tolerance level for outlier detection as 0.7.

%% Code Writen by LLM:
% Generate data for 'case14' with 400 training samples and 200 testing samples
 data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);

 % Filter out outliers from the training and testing datasets using the 'grubbs' method
 data = daline.filter(data, 'filter.switchTrain', 1, 'filter.switchTest', 1, 'filter.method', 'grubbs', 'filter.tol', 0.7);