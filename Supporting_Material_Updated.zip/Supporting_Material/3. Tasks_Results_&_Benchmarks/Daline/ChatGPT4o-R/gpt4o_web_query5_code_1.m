%% Prompt:
% Please write the code to prepare data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation.

%% Code Written by LLM:
% https://chatgpt.com/share/ce9de1f0-3475-4d5c-99e7-173f795f2e67
% Setting up options for data generation
opt = daline.setopt('case.name', 'case118', ...       % Specify the power system case
                    'num.trainSample', 500, ...       % Number of training samples
                    'data.baseType', 'TimeSeriesRand',... % Base type for data generation
                    'data.parallel', 1);              % Enable parallel computation

% Generating the data with the specified options
data = daline.generate(opt);

% Displaying some information about the generated data
disp('Data generation for case118 with 500 training samples and TimeSeriesRand base type completed.');
disp('Parallel computation enabled.');


%% MATLAB:
% The above code ran successfully