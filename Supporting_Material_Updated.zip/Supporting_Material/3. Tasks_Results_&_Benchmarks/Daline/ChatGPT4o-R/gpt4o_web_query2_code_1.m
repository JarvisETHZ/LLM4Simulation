%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples,
% and add noise with a signal-to-noise ratio of 45 dB.

%% Code Written by LLM:
% https://chatgpt.com/share/13873a18-7f6a-49a5-b434-31c13cf35865
% Define the options for data generation
opt = daline.setopt('case.name', 'case39', 'num.trainSample', 500, 'num.testSample', 300, 'data.fixRand', 1);

% Generate the data
data = daline.generate(opt);

% Define the options for adding noise
noise_opt = daline.setopt('noise.switchTrain', 1, 'noise.switchTest', 1, 'noise.SNR_dB', 45);

% Add noise to the generated data
data = daline.noise(data, noise_opt);

%% MATLAB:
% The above code ran successfully

%% Unnecessary Parameters:
% 'data.fixRand', 1