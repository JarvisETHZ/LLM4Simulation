
%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD.
% Set the data base type to 'TimeSeriesRand' and the number of training samples to 300.
% Disable the plotting.

%% Code Written by LLM:
% https://chatgpt.com/share/a10cdf58-143b-49e2-80b0-d1aa0db586fa
% Generate data with specified parameters
dataOptions = struct('case.name', 'case118', 'num.trainSample', 300, 'data.baseType', 'TimeSeriesRand', 'data.curvePlot', 0);
[dataTrain, ~, ~] = daline.data(dataOptions);

% Set method options
methodOptions = struct('method.name', 'LS_COD', 'PLOT.switch', 0);

% Fit the model using the specified method and options
model = daline.fit(dataTrain, methodOptions);

% Display the model parameters and any relevant output
disp(model);
