%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples, and add noise with a signal-to-noise ratio of 45 dB.

%% Code Writen by LLM:
% Generate data for 'case39' with specified number of training and testing samples
data = daline.generate('case.name', 'case39', 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand', 'num.trainSample', 500, 'num.testSample', 300);

% Add noise to the training data with a signal-to-noise ratio of 45 dB
data = daline.noise(data, 'noise.switchTrain', 1, 'noise.SNR_dB', 45);

% Add noise to the testing data with a signal-to-noise ratio of 45 dB
data = daline.noise(data, 'noise.switchTest', 1, 'noise.SNR_dB', 45);

%% MATLAB:
% The above code ran successfully

%% Unnecessary
% 'data.program', 'acpf', 'data.baseType', 'TimeSeriesRand'