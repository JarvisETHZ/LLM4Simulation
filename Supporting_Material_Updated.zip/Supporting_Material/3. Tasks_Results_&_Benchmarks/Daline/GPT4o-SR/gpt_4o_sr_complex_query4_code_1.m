%% Prompt:
% Generate data for 'case118' with 600 training samples and 300 testing samples. Compare and rank the accuracy of LS_COD and RR_VCS for 'case118'. Set the predictors to {'P', 'Vm2'} and responses to {'PF', 'QF'} for both methods. Set the lambda interval for Ordinary Ridge Regression with the Voltage-angle Coupling to 1e-7. Finally, set the plotting theme as 'academic', but disable the plotting. 

%% Code Writen by LLM:
% Step 1: Generate data for 'case118' with 600 training samples and 300 testing samples
data = daline.generateData('caseName', 'case118', 'data.train', 600, 'data.test', 300);

% Step 2: Fit models using LS_COD and RR_VCS methods
% Set options for LS_COD
opt_ls_cod = daline.setopt('method.name', 'LS_COD', ...
                           'variable.predictor', {'P', 'Vm2'}, ...
                           'variable.response', {'PF', 'QF'});

% Fit LS_COD model
model_ls_cod = daline.fit(data, opt_ls_cod);

% Set options for RR_VCS
opt_rr_vcs = daline.setopt('method.name', 'RR_VCS', ...
                           'variable.predictor', {'P', 'Vm2'}, ...
                           'variable.response', {'PF', 'QF'}, ...
                           'RR.lambdaInterval', 1e-7);

% Fit RR_VCS model
model_rr_vcs = daline.fit(data, opt_rr_vcs);

% Step 3: Compare and rank the accuracy of the models
results = daline.compare({'LS_COD', 'RR_VCS'}, data);

% Step 4: Set the plotting theme to 'academic' and disable plotting
daline.plot('theme', 'academic', 'plot', 0);

% Display the comparison results
disp(results);