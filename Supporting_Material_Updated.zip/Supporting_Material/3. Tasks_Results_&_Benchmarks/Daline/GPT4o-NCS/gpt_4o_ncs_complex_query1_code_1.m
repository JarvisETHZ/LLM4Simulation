%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare and rank the accuracy of the ordinary least squares, and the ordinary ridge regression for 'case14'. Set the regularization factor as 1e-10 for the ordinary ridge regression. Set the plotting responses to {'P', 'Vm2'} for all methods. Finally, use the dark style for plotting the ranking, and set the type of plotting as 'probability'. Disable the plotting. 

%% Code Writen by LLM:
% Step 1: Generate data for 'case14' with 400 training samples and 200 testing samples
data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);

% Step 2: Compare and rank the accuracy of the ordinary least squares (LS) and the ordinary ridge regression (RR)
methodList = {'LS', 'RR'};
opt = daline.setopt('RR.lambda', 1e-10, 'PLOT.response', {'P', 'Vm2'}, 'PLOT.style', 'dark', 'PLOT.type', 'probability', 'PLOT.switch', 0);
[models, failure] = daline.rank(data, methodList, opt);