%% Prompt:
% Please write the code to manage a complete cycle for 'case118' using the method LS_COD. Set the data base type to 'TimeSeriesRand' and the number of training samples to 300. Disable the plotting.

%% Code Writen by LLM:
model = daline.all('case118', 'data.baseType', 'TimeSeriesRand', 'num.trainSample', 300, 'method.name', 'LS_COD', 'PLOT.switch', 0);

%% MATLAB:
% The above code ran successfully