%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Generate data for 'case14' with 400 training samples and 200 testing samples
data = daline.data('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);

% Define the list of methods to compare
methodList = {'DLPF_C', 'PTDF'};

% Compare the accuracy of the specified methods
ranking = daline.rank(data, methodList);

%% MATLAB:
% The above code ran successfully