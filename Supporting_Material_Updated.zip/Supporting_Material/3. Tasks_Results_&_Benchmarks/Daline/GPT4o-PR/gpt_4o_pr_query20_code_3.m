%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Step 1: Generate data for 'case14'
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);
data = daline.data(opt);

% Step 2: Fit the models using DLPF_C and PTDF methods
model_DLPF_C = daline.fit(data, 'method.name', 'DLPF_C');
model_PTDF = daline.fit(data, 'method.name', 'PTDF');

% Step 3: Calculate prediction errors for the models
pred_DLPF_C = daline.predict(model_DLPF_C, data.test);
pred_PTDF = daline.predict(model_PTDF, data.test);

% Calculate Mean Absolute Error (MAE) as an example of accuracy metric
mae_DLPF_C = mean(abs(pred_DLPF_C - data.test.response), 'all');
mae_PTDF = mean(abs(pred_PTDF - data.test.response), 'all');

% Display the accuracy results
disp('Mean Absolute Error (MAE) of DLPF_C model:');
disp(mae_DLPF_C);

disp('Mean Absolute Error (MAE) of PTDF model:');
disp(mae_PTDF);