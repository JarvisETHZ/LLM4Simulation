%% Prompt:
% Generate data for 'case14' with 400 training samples and 200 testing samples. Compare the accuracy of Decoupled Linearized Power Flow with Data-driven Correction and Power Transfer Distribution Factor for 'case14'.

%% Code Writen by LLM:
% Step 1: Generate data for 'case14'
opt = daline.setopt('case.name', 'case14', 'num.trainSample', 400, 'num.testSample', 200);
data = daline.data(opt);

% Step 2: Fit the models using DLPF and PTDF methods
model_DLPF = daline.fit(data, 'method.name', 'DLPF');
model_PTDF = daline.fit(data, 'method.name', 'PTDF');

% Step 3: Compare the accuracy of the models
accuracy_DLPF = daline.evaluate(model_DLPF, data);
accuracy_PTDF = daline.evaluate(model_PTDF, data);

% Display the accuracy results
disp('Accuracy of DLPF model:');
disp(accuracy_DLPF);

disp('Accuracy of PTDF model:');
disp(accuracy_PTDF);