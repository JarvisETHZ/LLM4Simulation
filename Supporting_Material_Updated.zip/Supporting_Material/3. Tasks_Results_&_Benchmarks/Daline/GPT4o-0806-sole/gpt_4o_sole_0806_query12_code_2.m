%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Filter out outliers from the training dataset using the 'median' method and a tolerance of 5.

%% Code Writen by LLM:
% Generate data for 'case14'
data = generateDataSet('case14', 'train', 300, 'test', 200);

% Filter out outliers from the training dataset
filteredData = filterOutliers(data, 'filter.method', 'median', 'filter.tolerance', 5);