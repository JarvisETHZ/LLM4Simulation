%% Prompt:
% Please write the code to prepare data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation.

%% Code Writen by LLM:
% Prepare data for 'case118' with 500 training samples, 'TimeSeriesRand' base type, and enable parallel computation
PrepareData('case118', 'BaseType', 'TimeSeriesRand', 'NumTrain', 500, 'Parallel', true);