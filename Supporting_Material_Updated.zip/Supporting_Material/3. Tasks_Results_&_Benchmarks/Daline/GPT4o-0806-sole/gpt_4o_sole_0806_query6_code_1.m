%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Add noise to the data with a signal-to-noise ratio of 50 dB and enable the option for adding noise to the training dataset.

%% Code Writen by LLM:
% Load the case14 data
mpc = loadcase('case14');

% Set parameters for data generation
params = struct();
params.n_samples_train = 300; % Number of training samples
params.n_samples_test = 200;  % Number of testing samples
params.snr = 50;              % Signal-to-noise ratio in dB
params.add_noise = true;      % Enable noise addition to training data

% Generate data
[data_train, data_test] = generate_data(mpc, params);