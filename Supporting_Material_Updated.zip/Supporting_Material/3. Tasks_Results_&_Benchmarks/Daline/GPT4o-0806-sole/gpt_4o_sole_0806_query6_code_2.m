%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Add noise to the data with a signal-to-noise ratio of 50 dB and enable the option for adding noise to the training dataset.

%% Code Writen by LLM:
% Load the case14 data
mpc = loadcase('case14');

% Set parameters for data generation
params = struct();
params.nSamplesTrain = 300; % Number of training samples
params.nSamplesTest = 200;  % Number of testing samples
params.snr = 50;            % Signal-to-noise ratio in dB
params.addNoise = true;     % Enable noise addition to training data

% Generate data
[dataTrain, dataTest] = generateData(mpc, params);