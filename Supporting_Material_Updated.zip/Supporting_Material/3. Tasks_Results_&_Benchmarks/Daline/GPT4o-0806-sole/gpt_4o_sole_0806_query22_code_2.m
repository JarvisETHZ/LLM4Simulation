%% Prompt:
% Generate data for 'case14' with 300 training samples and 200 testing samples. Visualize the linearization results for Least Squares with Huber Weighting Function with a dark style and an academic theme. Disable the plotting.

%% Code Writen by LLM:
% Generate data for 'case14' with 300 training samples and 200 testing samples
data = DataGen('case14', 'n_train', 300, 'n_test', 200);

% Visualize the linearization results for Least Squares with Huber Weighting Function
visualize_linearization(data, 'method', 'LSHuber', 'style', 'dark', 'theme', 'academic', 'plotting', false);