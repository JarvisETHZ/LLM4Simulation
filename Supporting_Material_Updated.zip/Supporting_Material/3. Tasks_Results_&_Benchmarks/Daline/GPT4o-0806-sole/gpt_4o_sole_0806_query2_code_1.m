%% Prompt:
% Please write the code to create data for 'case39' with 500 training samples and 300 testing samples, and add noise with a signal-to-noise ratio of 45 dB.

%% Code Writen by LLM:
% Create data for 'case39' with 500 training samples and 300 testing samples
% Add noise with a signal-to-noise ratio of 45 dB

% Define the parameters for data creation
case_name = 'case39';
n_train = 500;
n_test = 300;
snr = 45;

% Create the data
create_data(case_name, 'n_train', n_train, 'n_test', n_test, 'snr', snr);